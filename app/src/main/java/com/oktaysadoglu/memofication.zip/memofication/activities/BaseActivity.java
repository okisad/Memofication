package com.oktaysadoglu.memofication.activities;

import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.Button;
import android.widget.Switch;

import com.oktaysadoglu.memofication.R;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by oktaysadoglu on 04/04/16.
 */
public class BaseActivity extends AppCompatActivity {

    @Bind(R.id.activity_main_navigation_view_notification_switch)
    Switch mNotificationOnOffSwitch;
    @Bind(R.id.activity_main_navigation_view_notification_number_button)
    Button mNotificationNumberButton;
    @Bind(R.id.toolbar)
    Toolbar mToolbar;
    @Bind(R.id.drawer_layout)
    DrawerLayout mDrawerLayout;
    @Bind(R.id.activity_level_navigation_view)
    NavigationView mNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ButterKnife.bind(this);

        setToolbar();

        setDrawerLayout();

    }

    private void setToolbar(){

        setSupportActionBar(mToolbar);

    }

    private void setDrawerLayout(){

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        mDrawerLayout.setDrawerListener(toggle);

        toggle.syncState();

        mNavigationView.setNavigationItemSelectedListener(this);

    }

}
