package com.oktaysadoglu.memofication.activities;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.oktaysadoglu.memofication.Memofication;
import com.oktaysadoglu.memofication.R;
import com.oktaysadoglu.memofication.db.UserWords;
import com.oktaysadoglu.memofication.db.UserWordsDao;
import com.oktaysadoglu.memofication.db.Word;
import com.oktaysadoglu.memofication.db.WordDao;

import butterknife.Bind;
import butterknife.ButterKnife;

public class PlacementTestActivity extends AppCompatActivity {

    @Bind(R.id.deneme)
    TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placement_test);

        ButterKnife.bind(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        WordDao mWordDao = Memofication.getWordDao();

        UserWordsDao userWordsDao = Memofication.getUserWordsDao();

        UserWords userWords = userWordsDao.loadByRowId(Long.parseLong("245"));

        Word word = mWordDao.load(Long.parseLong("245"));

        Log.e("my","geldi "+word.getMean());

        mTextView.setText(userWords.getWord_id()+" : "+userWords.getWord().getWord()+" : "+userWords.getWord().getMean());


    }

}
