package com.oktaysadoglu.memofication.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.NumberPicker;
import android.widget.Switch;
import android.widget.Toast;

import com.oktaysadoglu.memofication.R;
import com.oktaysadoglu.memofication.fragments.LevelListFragment;
import com.oktaysadoglu.memofication.fragments.WordListFragment;
import com.oktaysadoglu.memofication.fragments.pagers.PlayPagerFragment;
import com.oktaysadoglu.memofication.fragments.AchievementFragment;
import com.oktaysadoglu.memofication.recyclerViewAdapters.LevelListRecyclerViewAdapter;
import com.oktaysadoglu.memofication.tools.DialogTools;

import butterknife.Bind;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,CompoundButton.OnCheckedChangeListener,View.OnClickListener {

    @Bind(R.id.activity_main_navigation_view_notification_switch)
    Switch mNotificationOnOffSwitch;
    @Bind(R.id.activity_main_navigation_view_notification_number_button)
    Button mNotificationNumberButton;
    @Bind(R.id.toolbar)
    Toolbar mToolbar;
    @Bind(R.id.drawer_layout)
    DrawerLayout mDrawerLayout;
    @Bind(R.id.activity_level_navigation_view)
    NavigationView mNavigationView;

    private int mLevel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        setToolbar();

        setDrawerLayout();

        setFirstFragment();

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    /*@Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }*/

    @Override
    protected void onStart() {
        super.onStart();

        registerListeners();

    }

    private void setToolbar(){

        setSupportActionBar(mToolbar);

    }

    private void setDrawerLayout(){

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        mDrawerLayout.setDrawerListener(toggle);

        toggle.syncState();

        mNavigationView.setNavigationItemSelectedListener(this);

    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        Log.e("my", String.valueOf(id));

        if (id == R.id.nav_play) {
            setFragment(LevelListFragment.newInstance());
        } else if (id == R.id.nav_achievement) {
            setFragment(AchievementFragment.newInstance());
        }

        mDrawerLayout.closeDrawer(GravityCompat.START);

        return true;

    }

    private void registerListeners(){

        mNotificationNumberButton.setOnClickListener(this);

        mNotificationOnOffSwitch.setOnCheckedChangeListener(this);

    }

    private void setFirstFragment() {

        getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, LevelListFragment.newInstance()).setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).commit();

    }

    private void setFragment(Fragment fragment) {

        getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, fragment).setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).commit();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        /*if (requestCode == LevelListRecyclerViewAdapter.START_LEVEL_REQUEST_CODE){

            mLevel = data.getIntExtra("level",-1);

            setFragment(new LevelListFragment().newInstance());

        }*/
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        Toast.makeText(MainActivity.this, "changedCheck", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onClick(View v) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this,R.style.AppDialogTheme);

        View view = LayoutInflater.from(this).inflate(R.layout.navigation_change_number_of_notification_dialog,null);

        NumberPicker picker = (NumberPicker) view.findViewById(R.id.navigation_change_number_of_notification_dialog_number_picker);

        picker.setValue(0);
        picker.setMaxValue(10);
        picker.setMinValue(0);

        DialogTools dialogTools = new DialogTools();

        dialogTools.setNumberPickerTextColor(picker, ContextCompat.getColor(this, R.color.grey_900));
        dialogTools.setDividerColor(picker, ContextCompat.getColor(this, R.color.grey_700));

        final AlertDialog alertDialog = builder
                .setView(view)
                .setTitle("Number Of Notifications")
                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "okay", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
        }).create();


        alertDialog.show();

    }

}
