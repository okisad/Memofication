package com.oktaysadoglu.memofication.jobs;

import android.util.Log;

import com.birbit.android.jobqueue.Job;
import com.birbit.android.jobqueue.Params;
import com.birbit.android.jobqueue.RetryConstraint;
import com.oktaysadoglu.memofication.Memofication;
import com.oktaysadoglu.memofication.db.Word;
import com.oktaysadoglu.memofication.db.WordDao;
import com.oktaysadoglu.memofication.events.WordCardViewEvent;
import com.oktaysadoglu.memofication.model.WordCard;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import de.greenrobot.dao.query.Query;

/**
 * Created by oktaysadoglu on 12/02/16.
 */
public class WriteWordCardJob extends Job{

    private Word mMainWord;

    private ArrayList<String> mWordTypes;

    private int TAG;

    WordCard mWordCard;

    private long id;

    public WriteWordCardJob(long id) {
        super(new Params(1).setRequiresNetwork(false).addTags(String.valueOf(id)).persist());

        mWordCard = new WordCard();

        mWordTypes = new ArrayList<String>(){

            {
                add("inter.");
                add("u.");
                add("x");
            }

        };

        this.id = id;

        setMainWord();
    }

    @Override
    public void onAdded() {
/*
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }*/


    }

    @Override
    public void onRun() throws Throwable {

        WordCard wordCard = getWordCard();

        EventBus.getDefault().post(new WordCardViewEvent(wordCard));

    }

    @Override
    protected void onCancel(int cancelReason) {

    }

    @Override
    protected RetryConstraint shouldReRunOnThrowable(Throwable throwable, int runCount, int maxRunCount) {
        return null;
    }

    private void setMainWord(){

        mMainWord = Memofication.getWordDao().load(id);

        mWordCard.setMainWord(mMainWord);

    }

    private void listControl(List<Integer> integers) {

        if(id % 100 == 0){

            Log.e("test",id + " : control ediliyor ");

        }

        for (int v = 0; v < integers.size(); v++) {

            int s = integers.get(v);

            for (int k = v + 1; k < integers.size(); k++) {

                if (s == integers.get(k)) {

                    Log.e("PROBLEM","PROBLEM");

                }

            }

        }

    }

    public WordCard getWordCard(){

        List<Word> wordsForOptions = null;

        if (filterWordTypes()) {

            wordsForOptions = getWordsForOptions();

            List<Integer> integers = new ArrayList<>();

            mWordCard.setFirstOptionWord(wordsForOptions.get(0));
            mWordCard.setSecondOptionWord(wordsForOptions.get(1));
            mWordCard.setThirdOptionWord(wordsForOptions.get(2));
            mWordCard.setFourthOptionWord(wordsForOptions.get(3));

            mWordCard.shuffle();

        }else {

            wordsForOptions = getNotProperWordsForOptions();

            mWordCard.setFirstOptionWord(wordsForOptions.get(0));
            mWordCard.setSecondOptionWord(wordsForOptions.get(1));
            mWordCard.setThirdOptionWord(wordsForOptions.get(2));
            mWordCard.setFourthOptionWord(wordsForOptions.get(3));

            mWordCard.shuffle();
        }

        return mWordCard;

    }

    private boolean filterWordTypes(){

        if (!mWordTypes.contains(mMainWord.getType())){

            return true;

        }else {

            return false;

        }

    }

    private List<Word> getNotProperWordsForOptions(){

        WordDao wordDao = Memofication.getWordDao();

        List<Word> words = new ArrayList<>();

        Random random = new Random();

        int i = 0;

        words.add(mMainWord);

        while (i < 3){

            boolean bool = false;

            Long id = (long) random.nextInt(4000)+1;

            for (Word word : words){

                if (word.getId().equals(id)){

                    break;

                }

                if (words.get(words.size()-1).getId().equals(word.getId())){

                    bool = true;

                }
            }

            if (bool){

                Word word = wordDao.load(id);

                words.add(word);

                i++;

            }

        }

        return words;

    }

    private List<Word> getWordsForOptions(){

        List<Word> wordsForOptions = new ArrayList<>();

        WordDao wordDao = Memofication.getWordDao();

        Query query = wordDao.queryBuilder().where(WordDao.Properties.Type.eq(mMainWord.getType())).build();

        List<Word> words = query.list();

        if(words.size() < 4)
            return null;

        int i = 0;

        Random random = new Random();

        wordsForOptions.add(mMainWord);

        while (i < 3){

            boolean bool = false;

            Long id = (long) random.nextInt(words.size());

            for (Word word:wordsForOptions){

                if (word.getId().equals(id)){

                    break;

                }

                if (wordsForOptions.get(wordsForOptions.size()-1).getId().equals(word.getId())){

                    bool = true;

                }

            }

            if (bool){

                Word word = wordDao.load(id);

                wordsForOptions.add(word);

                i++;

            }

        }

        if (wordsForOptions.size() == 4){

            return wordsForOptions;

        }else {

            return null;

        }

    }

    public long getWordId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
